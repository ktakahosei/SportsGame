using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

// �o�g���V�X�e���̐���
public class Battle : MonoBehaviour
{
    // public�ϐ�
    [SerializeField] GameObject goalViewObject;
    [SerializeField] GameObject commandViewObject;
    [SerializeField] GameObject userGoalObject;
    [SerializeField] GameObject enemyGoalObject;
    [SerializeField] GameObject userTeamObject;
    [SerializeField] GameObject enemyTeamObject;
    [SerializeField] MainCamera mainCamera;
    [SerializeField] Ball ball;
    [SerializeField] State state;

    // private�ϐ�
    GameObject[] userObjects; // �SUser�I�u�W�F�N�g
    GameObject[] enemyObjects; // �SEnemy�I�u�W�F�N�g
    GameObject[] passObjects; // �p�X�\�ȃI�u�W�F�N�g
    CommandView commandView;
    UserCommandModel userCommandModel;
    EnemyCommandModel enemyCommandModel;
    string enemySelectedCommand; // �G���I�������R�}���h
    int rnd; // �����_���ϐ�

    void Start()
    {
        // �ϐ��̏����ݒ�
        {
            commandView = commandViewObject.GetComponent<CommandView>();
        }
    }

    void Update()
    {

    }

    public void SetUpGame()
    {
        // �X�N���v�g�ݒ�
        {
            // User�X�N���v�g�ݒ�
            {
                userObjects = new GameObject[userTeamObject.transform.childCount];
                for (int i = 0; i < userTeamObject.transform.childCount; i++)
                {
                    userObjects[i] = userTeamObject.transform.GetChild(i).gameObject;

                    switch (i)
                    {
                        case 0:
                            userObjects[i].GetComponent<UserCommandModel>().SetUp(ball, state, "User1", 80);
                            break;
                        case 1:
                            userObjects[i].GetComponent<UserCommandModel>().SetUp(ball, state, "User2", 80);
                            break;
                    }
                }
            }

            // Enemy�X�N���v�g�ݒ�
            {
                enemyObjects = new GameObject[enemyTeamObject.transform.childCount];
                for (int i = 0; i < enemyTeamObject.transform.childCount; i++)
                {
                    enemyObjects[i] = enemyTeamObject.transform.GetChild(i).gameObject;

                    switch (i)
                    {
                        case 0:
                            enemyObjects[i].GetComponent<EnemyCommandModel>().SetUp(userGoalObject, ball, state, "Enemy1", 80);
                            break;
                        case 1:
                            enemyObjects[i].GetComponent<EnemyCommandModel>().SetUp(userGoalObject, ball, state, "Enemy2", 80);
                            break;
                    }
                }
            }
        }
    }

    public void Restart()
    {
        goalViewObject.SetActive(false);
        commandViewObject.SetActive(false);

        {
            for (int i = 0; i < userTeamObject.transform.childCount; i++)
            {
                userObjects[i].GetComponent<UserCommandModel>().IsBall = false;
                enemyObjects[i].GetComponent<EnemyCommandModel>().IsBall = false;
            }
        }
    }

    // �R�}���h�J�n
    public void StartCommand(GameObject userObject, GameObject collisionObject, string panelName)
    {
        state.IsCommand = true;
        commandViewObject.SetActive(true);
        commandView.SelectedCommand(userObject, collisionObject, panelName);
    }

    // �o�g������
    public void CommandBattle(GameObject userObject, GameObject collisionObject, string selectedCommand)
    {
        // �ϐ��̑��
        userCommandModel = userObject.GetComponent<UserCommandModel>();

        // Enemy�̍s������
        if(collisionObject.gameObject.name == "Enemy(Clone)")
        {
            enemyCommandModel = collisionObject.GetComponent<EnemyCommandModel>();
            enemySelectedCommand = enemyCommandModel.SelectedCommand("EvU");
        }

        // �I�������R�}���h�ɉ���������
        switch (selectedCommand)
        {
            case "Pass":
                if(enemySelectedCommand == "PassCut")
                {
                    enemyCommandModel.PassCut(userObject);
                }
                else
                {
                    passObjects = new GameObject[userObjects.Length - 1];
                    for (int i = 0; i < userObjects.Length; i++)
                    {
                        int j = 0;
                        if (userObjects[i].GetComponent<UserCommandModel>().charaName != userCommandModel.charaName)
                        {
                            passObjects[j] = userObjects[i];
                            j++;
                        }
                    }

                    userCommandModel.Pass(collisionObject, passObjects[0]);
                }
                break;

            case "PassCut":
                if(enemySelectedCommand == "Pass")
                {
                    userCommandModel.PassCut(collisionObject);
                }
                else
                {
                    enemyCommandModel.Dribble(collisionObject, userGoalObject);
                }
                break;

            case "Dribble":
                if(enemySelectedCommand == "DribbleCut")
                {
                    enemyCommandModel.DribbleCut(userObject);
                }
                else
                {
                    userCommandModel.Dribble(collisionObject, enemyGoalObject);
                }
                break;

            case "DribbleCut":
                if(enemySelectedCommand == "Dribble")
                {
                    userCommandModel.DribbleCut(collisionObject);
                }
                else
                {
                    passObjects = new GameObject[enemyObjects.Length - 1];
                    for (int i = 0; i < enemyObjects.Length; i++)
                    {
                        int j = 0;
                        if (enemyObjects[i].GetComponent<EnemyCommandModel>().charaName != enemyCommandModel.charaName)
                        {
                            passObjects[j] = enemyObjects[i];
                            j++;
                        }
                    }

                    enemyCommandModel.Pass(userObject, passObjects[0]);
                }
                break;

            case "StrongShoot":
                userCommandModel.Shoot(enemyGoalObject, 20);
                break;

            case "NormalShoot":
                userCommandModel.Shoot(enemyGoalObject, 10);
                break;
        }
    }

    // �S�[���\��
    public void Goal()
    {
        state.IsGoal = true;
        goalViewObject.SetActive(true);
    }
}