using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPlayerCommand
{
    public void Blow(Vector3 blowVec);
}
