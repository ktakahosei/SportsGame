using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Setting : MonoBehaviour
{
    //public�ϐ�
    [SerializeField] GameObject mainCameraObject;
    [SerializeField] GameObject ballObject;
    [SerializeField] GameObject userGoalObject;
    [SerializeField] GameObject enemyGoalObject;
    [SerializeField] GameObject userTeamObject;
    [SerializeField] GameObject enemyTeamObject;
    [SerializeField] GameObject prefUserObject;
    [SerializeField] GameObject prefEnemyObject;
    [SerializeField] MainCamera mainCamera;
    [SerializeField] Ball ball;
    [SerializeField] State state;
    [SerializeField] Battle battle;
    public int playerNumber = 2;

    //private�ϐ�
    List<GameObject> userObjects = new List<GameObject>();
    List<GameObject> enemyObjects = new List<GameObject>();


    void Start()
    {
        playerNumber = 2;
        SetUpGame();
    }


    void Update()
    {

    }


    // �����̏����ݒ�
    public void SetUpGame()
    {
        // �I�u�W�F�N�g����
        {
            GameObject insObject;
            for (int p = 0; p < playerNumber; p++)
            {
                // User�I�u�W�F�N�g����
                {
                    insObject = Instantiate(prefUserObject, new Vector3(0.0f, 0.0f, 0.0f), Quaternion.identity);
                    insObject.transform.parent = userTeamObject.transform;
                    insObject.GetComponent<UserActionModel>().SetUp(mainCameraObject,ballObject,enemyGoalObject, battle, state);
                    userObjects.Add(insObject);
                }

                // Enemy�I�u�W�F�N�g����
                {
                    insObject = Instantiate(prefEnemyObject, new Vector3(0.0f, 0.0f, 0.0f), Quaternion.identity);
                    insObject.transform.parent = enemyTeamObject.transform;
                    insObject.GetComponent<EnemyActionModel>().SetUp(ballObject, userGoalObject, state);
                    enemyObjects.Add(insObject);
                }
            }
        }

        battle.SetUpGame();

        Restart();
    }


    // �����ĊJ
    public void Restart()
    {
        // �I�u�W�F�N�g�ʒu�ݒ�
        {
            for (int p = 0; p < playerNumber; p++)
            {
                ResetRigidbody(userObjects[p]);
                ResetRigidbody(enemyObjects[p]);

                userObjects[p].transform.position = userTeamObject.transform.position;
                enemyObjects[p].transform.position = enemyTeamObject.transform.position;

                // User�I�u�W�F�N�g�ʒu�ݒ�
                switch (p)
                {
                    case 0:
                        userObjects[p].transform.position += new Vector3(10.0f, 5.0f, -10.0f);
                        break;
                    case 1:
                        userObjects[p].transform.position += new Vector3(-10.0f, -5.0f, -15.0f);
                        break;
                }

                // Enemy�I�u�W�F�N�g�ʒu�ݒ�
                switch (p)
                {
                    case 0:
                        enemyObjects[p].transform.position += new Vector3(10.0f, 5.0f, 10.0f);
                        break;
                    case 1:
                        enemyObjects[p].transform.position += new Vector3(-10.0f, -5.0f, 15.0f);
                        break;
                }
            }
        }

        {
            for (int p = 0; p < playerNumber; p++)
            {
                userObjects[p].GetComponent<UserActionModel>().IsUser = false;
            }
        }

        {
            battle.Restart();
            state.Restart();

            GameObject isUserObject = userObjects[0];
            isUserObject.GetComponent<UserActionModel>().IsUser = true;
            mainCamera.Restart(isUserObject);

            GameObject isBallObject;
            int rnd;
            rnd = Random.Range(0, 100);
            if (rnd % 2 == 0)
            {
                isBallObject = userObjects[0];
            }
            else
            {
                isBallObject = enemyObjects[0];
            }
            ball.Restart(isUserObject, isBallObject);
        }
    }

    void ResetRigidbody(GameObject resetObject)
    {
        Rigidbody rb = resetObject.GetComponent<Rigidbody>();
        rb.transform.position = Vector3.zero;
        rb.transform.rotation = Quaternion.identity;

        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }
}
