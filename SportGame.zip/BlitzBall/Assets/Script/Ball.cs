using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    //public�ϐ�
    [SerializeField] MainCamera mainCamera;
    [SerializeField] State state;
    public int power = 0; // ���ˈЗ�

    //private�ϐ�
    GameObject collisionObject; // �Փ˂����I�u�W�F�N�g
    GameObject lastUserObject; // �O��̏Փ˂���User�I�u�W�F�N�g
    GameObject lastEnemyObject; // �O��̏Փ˂���Enemy�I�u�W�F�N�g
    GameObject ballCatchObject; // collisionObject�̎q�I�u�W�F�N�g
    Rigidbody rBody;
    float ballSpeed = 1000.0f; // ���ˑ��x


    void Start()
    {
        rBody = gameObject.GetComponent<Rigidbody>();
    }

    // �����ݒ�
    public void Restart(GameObject isUserObject, GameObject isBallObject)
    {
        lastUserObject = isUserObject;
        Catch(isBallObject);
    }

    void Update()
    {
        // �Ǐ]���������͔�Ǐ]��
        if (collisionObject != null)
        {
            transform.position = transform.parent.transform.position;
        }
    }


    // �{�[���擾����
    public void Catch(GameObject collisionObject)
    {
        // �{�[���擾�����J�n
        state.IsCatch = true;

        // �ϐ��X�V
        {
            this.collisionObject = collisionObject;
            ballCatchObject = collisionObject.transform.Find("BallCatch").gameObject;
            power = 0;
        }

        // �Փ˔��菈��
        {
            rBody.velocity = Vector3.zero;
            ColliderAvailable = false;
            collisionObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }

        // �ʒu�ݒ�
        {
            transform.position = new Vector3(ballCatchObject.transform.position.x, ballCatchObject.transform.position.y, ballCatchObject.transform.position.z);
            transform.SetParent(ballCatchObject.transform);
        }

        // �I�u�W�F�N�g�ʏՓˏ���
        if (collisionObject.gameObject.name == "User(Clone)")
        {
            // �t���O����
            {
                state.UserBall = true;

                if (lastUserObject != null)
                {
                    lastUserObject.gameObject.GetComponent<UserActionModel>().IsUser = false;
                    lastUserObject.gameObject.GetComponent<UserCommandModel>().IsBall = false;
                }

                if (lastEnemyObject != null)
                {
                    lastEnemyObject.gameObject.GetComponent<EnemyCommandModel>().IsBall = false;
                }

                collisionObject.gameObject.GetComponent<UserActionModel>().IsUser = true;
                collisionObject.gameObject.GetComponent<UserCommandModel>().IsBall = true;
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(collisionObject); }

            // �ϐ��̑��
            lastUserObject = collisionObject;

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
        if (collisionObject.gameObject.name == "Enemy(Clone)")
        {
            // �t���O����
            {
                state.UserBall = false;

                if (lastUserObject != null)
                {
                    lastUserObject.gameObject.GetComponent<UserCommandModel>().IsBall = false;
                }

                if (lastEnemyObject != null)
                {
                    lastEnemyObject.gameObject.GetComponent<EnemyCommandModel>().IsBall = false;
                }

                collisionObject.GetComponent<EnemyCommandModel>().IsBall = true;
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(lastUserObject); }

            // �ϐ��̑��
            lastEnemyObject = collisionObject;

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
        if (collisionObject.gameObject.name == "Keeper")
        {
            // �t���O����
            {
                if (state.userBall) { state.UserBall = false; } else { state.UserBall = true; }

                if (lastUserObject != null)
                {
                    lastUserObject.gameObject.GetComponent<UserCommandModel>().IsBall = false;
                }

                if (lastEnemyObject != null)
                {
                    lastEnemyObject.gameObject.GetComponent<EnemyCommandModel>().IsBall = false;
                }
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(lastUserObject); }

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
    }


    //���ˏ���
    public void Throw(Vector3 throwVec, int power)
    {
        // ���ˏ����J�n
        state.IsCatch = false;
        state.IsCommand = true;

        // �ϐ��̏�����
        {
            collisionObject = null;
            transform.parent = null;
        }

        // �{�[���̋����ݒ�
        {
            this.power = power;
        }

        // �Փ˔��菈��
        {
            rBody.velocity = throwVec.normalized * ballSpeed * Time.deltaTime;
            ColliderAvailable = false;
        }

        // �J�����ݒ�
        if (mainCamera != null) { mainCamera.Set(this.gameObject); }

        // ���ˌ㏈��
        Invoke("OnCollider", 0.5f);
        Invoke("ThrowDelay", 5.0f);
    }
    void ThrowDelay()
    {
        // �{�[���񏊎���
        if (!state.isCatch)
        {
            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(lastUserObject); }

            // �t���O����
            state.IsCommand = false;
        }
    }

    void OnCollider()
    {
        ColliderAvailable = true;
    }

    // Collider�@�\�̗L�����E������
    public bool ColliderAvailable
    {
        set
        {
            gameObject.GetComponent<SphereCollider>().enabled = value;
        }
    }
}
/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    //public�ϐ�
    [SerializeField] MainCamera mainCamera;
    [SerializeField] State state;
    public int power = 0; // ���ˈЗ�

    //private�ϐ�
    GameObject collisionObject; // �Փ˂����I�u�W�F�N�g
    GameObject lastUserObject; // �O��̏Փ˂���User�I�u�W�F�N�g
    GameObject lastEnemyObject; // �O��̏Փ˂���Enemy�I�u�W�F�N�g
    GameObject ballCatchObject; // collisionObject�̎q�I�u�W�F�N�g
    Rigidbody rBody;
    float ballSpeed = 1000.0f; // ���ˑ��x


    void Start()
    {

    }

    // �����ݒ�
    public void SetUp(GameObject isUserObject, GameObject isEnemyObject, bool userBall)
    {
        // �ϐ�������
        {
            this.lastUserObject = isUserObject;
            this.lastEnemyObject = isEnemyObject;
            state.UserBall = userBall;
            rBody = gameObject.GetComponent<Rigidbody>();
        }

        // Rigidbody������
        {
            rBody.velocity = Vector3.zero;
        }

        {
            if (state.userBall)
            {
                Catch(isUserObject);
            }
            else
            {
                Catch(isEnemyObject);
            }
        }
    }

    void Update()
    {
        // �Ǐ]���������͔�Ǐ]��
        if (collisionObject != null)
        {
            transform.position = transform.parent.transform.position;
        }
    }


    // �{�[���擾����
    public void Catch(GameObject collisionObject)
    {
        // �{�[���擾�����J�n
        state.IsCatch = true;

        // �ϐ��X�V
        {
            this.collisionObject = collisionObject;
            ballCatchObject = collisionObject.transform.Find("BallCatch").gameObject;
            power = 0;
        }

        // �Փ˔��菈��
        {
            ColliderAvailable = false;
        }

        {
            rBody.velocity = Vector3.zero;
            collisionObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }

        // �ʒu�ݒ�
        {
            transform.position = new Vector3(ballCatchObject.transform.position.x, ballCatchObject.transform.position.y, ballCatchObject.transform.position.z);
            transform.SetParent(ballCatchObject.transform);
        }

        // �I�u�W�F�N�g�ʏՓˏ���
        if (collisionObject.gameObject.name == "User(Clone)")
        {
            // �t���O����
            {
                state.UserBall = true;
                lastUserObject.gameObject.GetComponent<UserActionModel>().IsUser = false;
                lastUserObject.gameObject.GetComponent<UserCommandModel>().IsBall = false;
                collisionObject.gameObject.GetComponent<UserActionModel>().IsUser = true;
                collisionObject.gameObject.GetComponent<UserCommandModel>().IsBall = true;
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(collisionObject); }

            // �ϐ��̑��
            lastUserObject = collisionObject;

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
        if (collisionObject.gameObject.name == "Enemy(Clone)")
        {
            // �t���O����
            {
                state.UserBall = false;
                lastEnemyObject.gameObject.GetComponent<EnemyCommandModel>().IsBall = false;
                collisionObject.GetComponent<EnemyCommandModel>().IsBall = true;
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(lastUserObject); }

            // �ϐ��̑��
            lastEnemyObject = collisionObject;

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
        if (collisionObject.gameObject.name == "Agent(Clone)")
        {
            // �t���O����
            {
                state.UserBall = true;
                lastUserObject.gameObject.GetComponent<AgentActionModel>().IsAgent = false;
                lastUserObject.gameObject.GetComponent<AgentCommandModel>().IsBall = false;
                collisionObject.gameObject.GetComponent<AgentActionModel>().IsAgent = true;
                collisionObject.gameObject.GetComponent<AgentCommandModel>().IsBall = true;
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(collisionObject); }

            // �ϐ��̑��
            lastUserObject = collisionObject;

            // �R�}���h�퓬�I��
            state.IsCommand = false;
        }
        if (collisionObject.gameObject.name == "Keeper")
        {
            // �t���O����
            {
                if (state.userBall) { state.UserBall = false; } else { state.UserBall = true; }
            }

            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(collisionObject); }
        }
    }


    //���ˏ���
    public void Throw(Vector3 vector, int power)
    {
        // ���ˏ����J�n
        state.IsCatch = false;

        // �ϐ��̏�����
        {
            collisionObject = null;
            transform.parent = null;
        }

        // �{�[���̋����ݒ�
        {
            this.power = power;
        }

        // �Փ˔��菈��
        {
            ColliderAvailable = false;
        }

        // Rigidbody����
        {
            rBody.velocity = vector.normalized * ballSpeed * Time.deltaTime;
        }

        // �J�����ݒ�
        if (mainCamera != null) { mainCamera.Set(this.gameObject); }

        // ���ˌ㏈��
        Invoke("OnCollider", 0.5f);
        Invoke("ThrowDelay", 5.0f);
    }
    void ThrowDelay()
    {
        // �{�[���񏊎���
        if (!state.isCatch)
        {
            // �J�����ݒ�
            if (mainCamera != null) { mainCamera.Set(lastUserObject); }

            // �t���O����
            state.IsCommand = false;
        }
    }

    void OnCollider()
    {
        ColliderAvailable = true;
    }

    // Collider�@�\�̗L�����E������
    public bool ColliderAvailable
    {
        set
        {
            gameObject.GetComponent<SphereCollider>().enabled = value;
        }
    }
}
*/
