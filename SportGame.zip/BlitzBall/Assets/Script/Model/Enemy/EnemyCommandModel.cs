using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Enemy�̃R�}���h����
public class EnemyCommandModel : PlayerCommandModel
{
    //public�ϐ�
    [SerializeField] GameObject userGoalObject;

    // �L�����N�^�[�f�[�^(�����X�e�[�^�X)
    [Header("�L�����N�^�[��")]
    public string charaName;
    [Header("�ő�HP(����HP)")]
    public int maxHP;
    public int hp;

    void Start()
    {

    }

    // �����ݒ�
    public void SetUp(GameObject userGoalObject, Ball ball, State state,string charaName, int maxHP)
    {
        this.userGoalObject = userGoalObject;
        this.ball = ball;
        this.state = state;
        this.charaName = charaName;
        this.maxHP = maxHP;
        hp = maxHP;
    }

    void Update()
    {

    }

    // �R�}���h�I�𑀍�
    public string SelectedCommand(string panelName)
    {
        string selectedCommand = "";
        switch (panelName)
        {
            case "EvU":
                int rnd;
                rnd = Random.Range(0, 100);
                rnd = rnd % 3;

                if (!state.userBall)
                {
                    if(hp >= 20)
                    {
                        switch (rnd)
                        {
                            case 0:
                                selectedCommand = "Pass";
                                break;

                            case 1:
                            case 2:
                                hp -= 20;
                                selectedCommand = "Dribble";
                                break;
                        }
                    }
                    else
                    {
                        selectedCommand = "Pass";
                    }
                }
                else
                {
                    if (hp >= 10)
                    {
                        switch (rnd)
                        {
                            case 0:
                                hp -= 10;
                                selectedCommand = "DribbleCut";
                                break;

                            case 1:
                            case 2:
                                selectedCommand = "PassCut";
                                break;
                        }
                    }
                    else
                    {
                        selectedCommand = "PassCut";
                    }
                }
                break;
        }
        
        return selectedCommand;
    }

    // �S�[���O�ł̃R�}���h�I�𑀍�
    public void EvG()
    {
        state.IsCommand = true;

        // �ϐ��̑��
        if (hp >= 20)
        {
            hp -= 20;
            Shoot(userGoalObject, 20);
        }
        else
        {
            Shoot(userGoalObject, 10);
        }
    }
}
