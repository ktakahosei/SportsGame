using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeeperModel : MonoBehaviour
{
    // public�ϐ�
    [SerializeField] GameObject allyTeamObject;
    [SerializeField] GameObject oppoTeamObject;
    [SerializeField] Ball ball;
    [SerializeField] State state;
    [SerializeField] Battle battle;
    public bool userKeeper = false; // ��������

    // private�ϐ�
    GameObject[] allyObjects; // �SUser��������Enemy�I�u�W�F�N�g
    GameObject[] oppoObjects;
    Vector3 passVec; // �p�X����
    Vector3 goalVec; // �S�[������
    Vector3 blowVec; // ������΂�����

    // �L�����N�^�[�f�[�^(�����X�e�[�^�X)
    [Header("�ő�HP(����HP)")]
    public int maxHP;
    public int hp;


    void Start()
    {

        // �L�����N�^�[�f�[�^�̏����ݒ�
        {
            maxHP = 40;
            hp = maxHP;
        }
    }

    void Update()
    {

    }

    //�Փˏ���
    void OnTriggerStay(Collider trigger)
    {
        //Ball�Ƃ̏Փ˔���
        if (trigger.gameObject.name == "Ball")
        {
            state.IsCommand = true;

            if (hp >= ball.power)
            {
                hp -= ball.power;

                ball.Catch(gameObject);

                Invoke("Keep", 1.5f);
            }
            else
            {
                if (ball.power > 10)
                {
                    {
                        goalVec = new Vector3(transform.position.x - trigger.gameObject.transform.position.x, transform.position.y - trigger.gameObject.transform.position.y, transform.position.z - trigger.gameObject.transform.position.z);
                    }

                    {
                        ball.Throw(goalVec, 0);
                    }

                    if (userKeeper)
                    {
                        if (battle != null) { battle.Goal(); }
                    }
                    else
                    {
                        if (battle != null) { battle.Goal(); }
                    }
                }
                else
                {
                    int rnd;
                    rnd = Random.Range(0, 100);
                    rnd = rnd % 2;

                    switch (rnd)
                    {
                        case 0:
                            {
                                goalVec = new Vector3(transform.position.x - trigger.gameObject.transform.position.x, transform.position.y - trigger.gameObject.transform.position.y, transform.position.z - trigger.gameObject.transform.position.z);
                            }

                            {
                                ball.Throw(goalVec, 0);
                            }

                            if (userKeeper)
                            {
                                if (battle != null) { battle.Goal(); }
                            }
                            else
                            {
                                if (battle != null) { battle.Goal(); }
                            }
                            break;
                        case 1:
                            ball.Catch(gameObject);

                            Invoke("Keep", 1.5f);
                            break;
                    }
                }
            }
        }
    }

    void Keep()
    {
        if (allyObjects == null)
        {
            allyObjects = new GameObject[allyTeamObject.transform.childCount];
            for (int i = 0; i < allyTeamObject.transform.childCount; i++)
            {
                allyObjects[i] = allyTeamObject.transform.GetChild(i).gameObject;
            }
        }

        int rnd; // �����_���ϐ�
        rnd = Random.Range(0, 100);
        rnd = rnd % allyObjects.Length;

        Pass(allyObjects[rnd]);
    }

    void Pass(GameObject passObject)
    {
        if (oppoObjects == null)
        {
            oppoObjects = new GameObject[oppoTeamObject.transform.childCount];
            for (int i = 0; i < oppoTeamObject.transform.childCount; i++)
            {
                oppoObjects[i] = oppoTeamObject.transform.GetChild(i).gameObject;
            }
        }

        for(int i = 0; i < oppoObjects.Length; i++)
        {
            oppoObjects[i].GetComponent<SphereCollider>().enabled = false;
        }

        // �p�X�����̐ݒ�
        {
            passVec = new Vector3(passObject.transform.position.x - transform.position.x, passObject.transform.position.y - transform.position.y, passObject.transform.position.z - transform.position.z);
        }

        // �p�X����
        {
            ball.Throw(passVec, 0);
        }

        Invoke("PassDelay", 2.0f);
    }

    void PassDelay()
    {
        for (int i = 0; i < oppoObjects.Length; i++)
        {
            oppoObjects[i].GetComponent<SphereCollider>().enabled = true;
        }
    }

    // �Փ˔���̐ݒ�
    public bool ColliderAvailable
    {
        set
        {
            gameObject.GetComponent<SphereCollider>().enabled = value;
        }
    }
}
