using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// User�̃A�N�V��������
public class UserActionModel : PlayerActionModel
{
    //public�ϐ�
    [SerializeField] GameObject mainCameraObject;
    [SerializeField] GameObject ballObject;
    [SerializeField] GameObject enemyGoalObject;
    [SerializeField] Battle battle;
    [SerializeField] State state;
    public bool isUser = false; //���쒆����

    //private�ϐ�
    MainCamera mainCamera;
    UserCommandModel userCommandModel;
    Vector3 forward; //�J�����̑O����
    Vector3 right; //�J�����̉E����


    void Start()
    {

    }

    // �ϐ��̏����ݒ�
    public void SetUp(GameObject mainCameraObject, GameObject ballObject, GameObject enemyGoalObject, Battle battle, State state)
    {
        this.mainCameraObject = mainCameraObject;
        this.ballObject = ballObject;
        this.enemyGoalObject = enemyGoalObject;
        this.mainCamera = mainCameraObject.GetComponent<MainCamera>();
        this.battle = battle;
        this.state = state;
        this.userCommandModel = gameObject.GetComponent<UserCommandModel>();
        rBody = gameObject.GetComponent<Rigidbody>();
    }

    void Update()
    {
        //�A�N�V�����ƃR�}���h�ł̋@�\�؂�ւ�
        if (!state.isCommand)
        {
            if (!userCommandModel.isStop)
            {
                //���[�U�[����ł̋@�\�؂�ւ�
                if (isUser)
                {
                    //�ړ������x�N�g���̐ݒ�
                    {
                        //�O�����ƉE�����̐ݒ�
                        forward = Vector3.Scale(mainCameraObject.transform.forward, new Vector3(1, 0, 1)).normalized;
                        right = Vector3.Scale(mainCameraObject.transform.right, new Vector3(1, 0, 1)).normalized;

                        //�ړ������x�N�g���̏�����
                        moveVec = Vector3.zero;

                        //�ړ��L�[���͐ݒ�
                        {
                            if (Input.GetKey(KeyCode.W))
                            {
                                moveVec += forward;
                            }
                            if (Input.GetKey(KeyCode.A))
                            {
                                moveVec += -1 * right;
                            }
                            if (Input.GetKey(KeyCode.S))
                            {
                                moveVec += -1 * forward;
                            }
                            if (Input.GetKey(KeyCode.D))
                            {
                                moveVec += right;
                            }
                            if (Input.GetKey(KeyCode.Space))
                            {
                                moveVec += new Vector3(0, 2, 0);
                            }
                            if (Input.GetKey(KeyCode.LeftShift))
                            {
                                moveVec += new Vector3(0, -2, 0);
                            }


                        }

                        //�ړ������x�N�g���̐ݒ�
                        moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                    }

                    // ���̑��L�[���͐ݒ�
                    {
                        if (Input.GetKeyDown(KeyCode.E))
                        {
                            if (userCommandModel.hp >= 10)
                            {
                                userCommandModel.hp -= 10;
                                MoveSpeedUp();
                            }
                        }
                    }
                }
                else
                {
                    // �{�[�������t���O�ɂ��@�\�؂�ւ�
                    if (state.isCatch)
                    {
                        // �����{�[���t���O�ɂ��@�\�؂�ւ�
                        if (state.userBall)
                        {
                            //�ړ������x�N�g���̐ݒ�
                            {
                                //�ړ������x�N�g���̏�����
                                moveVec = Vector3.zero;

                                //�ړ������x�N�g���̐ݒ�
                                moveVec = new Vector3(enemyGoalObject.transform.position.x - transform.position.x, enemyGoalObject.transform.position.y - transform.position.y, enemyGoalObject.transform.position.z - transform.position.z);
                                moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                            }
                        }
                        else
                        {
                            //�ړ������x�N�g���̐ݒ�
                            {
                                //�ړ������x�N�g���̏�����
                                moveVec = Vector3.zero;

                                //�ړ������x�N�g���̐ݒ�
                                moveVec = new Vector3(ballObject.transform.position.x - transform.position.x, ballObject.transform.position.y - transform.position.y, ballObject.transform.position.z - transform.position.z);
                                moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                            }
                        }
                    }
                    else
                    {
                        //�ړ������x�N�g���̐ݒ�
                        {
                            //�ړ������x�N�g���̏�����
                            moveVec = Vector3.zero;

                            //�ړ������x�N�g���̐ݒ�
                            moveVec = new Vector3(ballObject.transform.position.x - transform.position.x, ballObject.transform.position.y - transform.position.y, ballObject.transform.position.z - transform.position.z);
                            moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                        }
                    }

                }
            }
            

            // �ړ���
            if (moveVec.magnitude > 0)
            {
                //���[�U�[�̉�]
                {
                    nextPos = transform.position + moveVec;
                    pos = transform.position;

                    //Vector3.SmoothDamp��Vector3�^�̒l�����X�ɕω������� //Vector3.SmoothDamp (���ݒn, �ړI�n, ref ���݂̑��x, �J�ڎ���, �ō����x)
                    angle = Mathf.SmoothDampAngle(0, Vector3.Angle(transform.forward, nextPos - pos), ref turnSpeed, smoothTime, maxAngularVelocity);

                    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(nextPos - pos, Vector3.up), angle);
                }

                rBody.velocity = moveVec;
            }
        }
    }

    // �Փˏ���
    void OnCollisionEnter(Collision collision)
    {
        // Ball�Ƃ̏Փˏ���
        if (collision.gameObject.name == "Ball")
        {
            collision.gameObject.GetComponent<Ball>().Catch(this.gameObject);
        }

        if (!state.isCommand)
        {
            if (state.isCatch)
            {
                // �����{�[���t���O�ɂ��@�\�؂�ւ�
                if (state.userBall)
                {
                    // ���[�U�[�����User����̏���
                    if (userCommandModel.isBall)
                    {
                        //Enemy�Ƃ̏Փˏ���
                        if (collision.gameObject.name == "Enemy(Clone)")
                        {

                            // ���x�̏�����
                            {
                                rBody.velocity = Vector3.zero;
                                collision.gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
                            }

                            battle.StartCommand(this.gameObject, collision.gameObject, "UvE");
                        }
                    }
                }
                else
                {
                    //Enemy�Ƃ̏Փ˔���
                    if (collision.gameObject.name == "Enemy(Clone)")
                    {
                        if (collision.gameObject.GetComponent<EnemyCommandModel>().isBall)
                        {

                            // ���x�̏�����
                            {
                                rBody.velocity = Vector3.zero;
                                collision.gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
                            }

                            mainCamera.Set(this.gameObject);
                            battle.StartCommand(this.gameObject, collision.gameObject, "UvE");
                        }
                    }
                }
            }
        }
    }

    void OnTriggerStay(Collider trigger)
    {
        if (!state.isCommand)
        {
            if (userCommandModel.isBall)
            {
                if (trigger.gameObject.name == "EnemyGoal")
                {
                    rBody.velocity = Vector3.zero;
                    battle.StartCommand(this.gameObject, trigger.gameObject, "UvG");
                }
            }
        }
    }

    // ���[�U�[���씻��̐ݒ�
    public bool IsUser
    {
        set
        {
            isUser = value;
        }
    }
}