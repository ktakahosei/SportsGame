using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCamera : MonoBehaviour
{
    //public�ϐ�
    [SerializeField] State state;
    public float sensitivity = 5.0f; //�J�������x

    //private�ϐ�
    GameObject frontObject; // �Ǐ]��I�u�W�F�N�g
    Vector3 pos; //User�̌��ݒn
    Vector3 pastPos; //User�̉ߋ��ʒu


    void Start()
    {
        sensitivity = 5.0f;
        pastPos = frontObject.transform.position;
    }

    void Update()
    {
        if (!state.isCommand)
        {
            //�J�����̉�]
            {
                float mx = Input.GetAxis("Mouse X");
                float my = Input.GetAxis("Mouse Y");

                if (Mathf.Abs(mx) > 0.01f)
                {
                    transform.RotateAround(frontObject.transform.position, Vector3.up, mx * sensitivity);
                }
                if (Mathf.Abs(my) > 0.01f)
                {
                    transform.RotateAround(frontObject.transform.position, transform.right, -my * sensitivity);
                }
            }
        }

        //�J�����̈ʒu
        {
            pos = frontObject.transform.position;
            transform.position = Vector3.Lerp(transform.position, transform.position + pos - pastPos, 1.0f);
            pastPos = pos;
        }
    }

    public void Restart(GameObject isUserObject)
    {
        Set(isUserObject);
    }

    // �Ǐ]�ݒ�
    public void Set(GameObject frontObject)
    {
        {
            transform.position = new Vector3(0.0f, 0.0f, 0.0f);
            transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
        }

        this.frontObject = frontObject;

        // �ʒu�ݒ�
        {
            pastPos = frontObject.transform.position;
            transform.position = frontObject.transform.position;
            transform.position += new Vector3(0.0f, 2.0f, -5.0f);
        }
    }
}
