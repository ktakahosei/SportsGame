using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//�������Ɋւ���X�N���v�g
public class Stage : MonoBehaviour
{
    //public float resSpeed = 500.0f; // �ړ����x

    // private�ϐ�
    Vector3 resVec;

    void Start()
    {
        
    }

    void Update()
    {
        
    }

    void OnTriggerExit(Collider trigger)
    {
        // �C������W�̐ݒ�
        {
            resVec = new Vector3(trigger.gameObject.transform.position.x - transform.position.x, trigger.gameObject.transform.position.y - transform.position.y, trigger.gameObject.transform.position.z - transform.position.z);
            resVec = resVec.normalized * Time.deltaTime;
        }

        {
            trigger.gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
            trigger.gameObject.GetComponent<Rigidbody>().velocity = resVec;
        }
    }
}
