using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStatusView : MonoBehaviour
{
    [SerializeField] GameObject playerObject;
    [SerializeField] Text hpText;

    int hp;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (playerObject.gameObject.name == "User(Clone)")
        {
            hp = playerObject.GetComponent<UserCommandModel>().hp;
        }
        else if (playerObject.gameObject.name == "Enemy(Clone)")
        {
            hp = playerObject.GetComponent<EnemyCommandModel>().hp;
        }
        else if (playerObject.gameObject.name == "Keeper")
        {
            hp = playerObject.GetComponent<KeeperModel>().hp;
        }

        hpText.text = "HP: " + hp;
    }
}
