using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class State : MonoBehaviour
{
    public bool userBall = false; // �`�[���{�[���t���O
    public bool isCatch = false; // �v���C���[�����t���O
    public bool isCommand = false; // �R�}���h����
    public bool isGoal = false; // �S�[������

    public void Restart()
    {
        UserBall = false;
        IsCatch = false;
        IsCommand = false;
        IsGoal = false;
    }

    public bool UserBall
    {
        set
        {
            userBall = value;
        }
    }
    public bool IsCatch
    {
        set
        {
            isCatch = value;
        }
    }
    public bool IsCommand
    {
        set
        {
            isCommand = value;
        }
    }
    public bool IsGoal
    {
        set
        {
            isGoal = value;
        }
    }
}
