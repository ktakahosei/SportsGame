using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Enemy�̃A�N�V��������
public class EnemyActionModel : PlayerActionModel
{
    //public�ϐ�
    [SerializeField] GameObject ballObject;
    [SerializeField] GameObject userGoalObject;
    [SerializeField] State state;

    //private�ϐ�
    EnemyCommandModel enemyCommandModel;

    void Start()
    {

    }

    // �ϐ��̏����ݒ�
    public void SetUp(GameObject ballObject, GameObject userGoalObject, State state)
    {
        this.ballObject = ballObject;
        this.userGoalObject = userGoalObject;
        this.state = state;
        this.enemyCommandModel = gameObject.GetComponent<EnemyCommandModel>();
        rBody = gameObject.GetComponent<Rigidbody>();
    }

    void Update()
    {
        //�A�N�V�����ƃR�}���h�ł̋@�\�؂�ւ�
        if (!state.isCommand)
        {
            if (!enemyCommandModel.isStop)
            {
                if (state.isCatch)
                {
                    
                    // �{�[�������ɂ��@�\�؂�ւ�
                    if (!state.userBall)
                    {
                        //�ړ������x�N�g���̐ݒ�
                        {
                            //�ړ������x�N�g���̏�����
                            moveVec = Vector3.zero;

                            //�ړ������x�N�g���̐ݒ�
                            moveVec = new Vector3(userGoalObject.transform.position.x - transform.position.x, userGoalObject.transform.position.y - transform.position.y, userGoalObject.transform.position.z - transform.position.z);
                            moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                        }
                    }
                    else
                    {
                        //�ړ������x�N�g���̐ݒ�
                        {
                            //�ړ������x�N�g���̏�����
                            moveVec = Vector3.zero;

                            //�ړ������x�N�g���̐ݒ�
                            moveVec = new Vector3(ballObject.transform.position.x - transform.position.x, ballObject.transform.position.y - transform.position.y, ballObject.transform.position.z - transform.position.z);
                            moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                        }
                    }
                }
                else
                {
                    //�ړ������x�N�g���̐ݒ�
                    {
                        //�ړ������x�N�g���̏�����
                        moveVec = Vector3.zero;

                        //�ړ������x�N�g���̐ݒ�
                        moveVec = new Vector3(ballObject.transform.position.x - transform.position.x, ballObject.transform.position.y - transform.position.y, ballObject.transform.position.z - transform.position.z);
                        moveVec = moveVec.normalized * moveSpeed * Time.deltaTime;
                    }
                }
            }
            
            //�ړ���
            if (moveVec.magnitude > 0)
            {
                //���[�U�[�̉�]
                {
                    nextPos = transform.position + moveVec;
                    pos = transform.position;

                    //Vector3.SmoothDamp��Vector3�^�̒l�����X�ɕω������� //Vector3.SmoothDamp (���ݒn, �ړI�n, ref ���݂̑��x, �J�ڎ���, �ō����x)
                    angle = Mathf.SmoothDampAngle(0, Vector3.Angle(transform.forward, nextPos - pos), ref turnSpeed, smoothTime, maxAngularVelocity);

                    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(nextPos - pos, Vector3.up), angle);
                }

                rBody.velocity = moveVec;
            }
        }
    }

    //�Փ˔���
    void OnCollisionEnter(Collision collision)
    {
        //Ball�Ƃ̏Փ˔���
        if (collision.gameObject.name == "Ball")
        {
            collision.gameObject.GetComponent<Ball>().Catch(this.gameObject);
        }

        if (!state.isCommand)
        {
            if (state.isCatch)
            {
                if (!state.userBall)
                {
                    if (enemyCommandModel.isBall)
                    {
                        if (collision.gameObject.name == "User(Clone)")
                        {

                        }
                    }
                }
                else
                {
                    //Enemy�Ƃ̏Փ˔���
                    if (collision.gameObject.name == "User(Clone)")
                    {
                        if (collision.gameObject.GetComponent<UserCommandModel>().isBall)
                        {

                        }
                    }
                }
            }
        }
    }

    void OnTriggerStay(Collider trigger)
    {
        if (!state.isCommand)
        {
            if (enemyCommandModel.isBall)
            {
                if (trigger.gameObject.name == "UserGoal")
                {
                    rBody.velocity = Vector3.zero;
                    enemyCommandModel.EvG();
                }
            }
        }
    }
}