using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

// �R�}���hUI�̐���
public class CommandView : MonoBehaviour
{
    // public�ϐ�
    [SerializeField] GameObject uve; // UvE�I�u�W�F�N�g
    [SerializeField] GameObject uvg; // UvG�I�u�W�F�N�g
    [SerializeField] GameObject onPassPanel; // OnPassPanel�I�u�W�F�N�g
    [SerializeField] GameObject onShootPanel; // OnPassPanel�I�u�W�F�N�g
    [SerializeField] State state;
    [SerializeField] Battle battle;

    // private�ϐ�
    GameObject userObject; // �C���X�^���X�G���[�΍�
    UserCommandModel userCommandModel;
    Button passButton;
    Button passCutButton;
    Button dribbleButton;
    Button dribbleCutButton;
    Button shootButton;
    Button strongShootButton;
    Button normalShootButton;

    void Start()
    {

    }

    void Update()
    {

    }

    // ���쒆�̃p�l���ݒ�
    public void SelectedCommand(GameObject userObject, GameObject collisionObject, string panelName)
    {
        // �C���X�^���X�G���[�΍�
        this.userObject = userObject;

        // �ϐ��̑��
        userCommandModel = this.userObject.GetComponent<UserCommandModel>();

        // UvE�p�l������
        if (panelName == "UvE")
        {
            // �p�l���\��
            uve.SetActive(true);

            // Button�ݒ�
            {
                passButton = uve.transform.Find("PassButton").gameObject.GetComponent<Button>();
                passCutButton = uve.transform.Find("PassCutButton").gameObject.GetComponent<Button>();
                dribbleButton = uve.transform.Find("DribbleButton").gameObject.GetComponent<Button>();
                dribbleCutButton = uve.transform.Find("DribbleCutButton").gameObject.GetComponent<Button>();
            }

            // Button����
            {
                passButton.enabled = true;
                passCutButton.enabled = true;
                dribbleButton.enabled = true;
                dribbleCutButton.enabled = true;
                if (userCommandModel.hp < 20) { dribbleButton.enabled = false; }
                if (userCommandModel.hp < 10) { dribbleCutButton.enabled = false; }
            }

            // Button�\��
            {
                // �����{�[������ł̋@�\�؂�ւ�
                if (state.userBall)
                {
                    uve.transform.Find("PassButton").gameObject.SetActive(true);
                    uve.transform.Find("PassCutButton").gameObject.SetActive(false);
                    uve.transform.Find("DribbleButton").gameObject.SetActive(true);
                    uve.transform.Find("DribbleCutButton").gameObject.SetActive(false);
                }
                else
                {
                    uve.transform.Find("PassButton").gameObject.SetActive(false);
                    uve.transform.Find("PassCutButton").gameObject.SetActive(true);
                    uve.transform.Find("DribbleButton").gameObject.SetActive(false);
                    uve.transform.Find("DribbleCutButton").gameObject.SetActive(true);
                }
            }

            // Button���s����
            {
                OnPassButton.AddListener(() => {
                    battle.CommandBattle(this.userObject, collisionObject, "Pass");
                    Close();
                    OnPassButton.RemoveAllListeners(); // �C�x���g�d�����s�΍�
                });
                OnPassCutButton.AddListener(() => {
                    battle.CommandBattle(this.userObject, collisionObject, "PassCut");
                    Close();
                    OnPassCutButton.RemoveAllListeners();
                });
                OnDribbleButton.AddListener(() => {
                    userCommandModel.hp -= 20;
                    battle.CommandBattle(this.userObject, collisionObject, "Dribble");
                    Close();
                    OnDribbleButton.RemoveAllListeners();
                });
                OnDribbleCutButton.AddListener(() => {
                    userCommandModel.hp -= 10;
                    battle.CommandBattle(this.userObject, collisionObject, "DribbleCut");
                    Close();
                    OnDribbleCutButton.RemoveAllListeners();
                });
            }
        }

        // UvG�p�l������
        if (panelName == "UvG")
        {
            // �p�l���\��
            uvg.SetActive(true);

            // Button�ݒ�
            {
                passButton = uvg.transform.Find("PassButton").gameObject.GetComponent<Button>();
                shootButton = uvg.transform.Find("ShootButton").gameObject.GetComponent<Button>();
            }

            // Button����
            {
                passButton.enabled = true;
                shootButton.enabled = true;
            }
            
            // Button���s����
            {
                OnPassButton.AddListener(() => {
                    passButton.enabled = false;
                    shootButton.enabled = false;
                    battle.CommandBattle(this.userObject, collisionObject, "Pass");
                    Close();
                    OnPassButton.RemoveAllListeners();
                });
                OnShootButton.AddListener(() => {
                    passButton.enabled = false;
                    shootButton.enabled = false;
                    SelectedCommand(this.userObject, collisionObject, "OnShootPanel");
                    OnShootButton.RemoveAllListeners();
                });
            }
        }

        // OnPassPanel�p�l������
        if (panelName == "OnShootPanel")
        {
            // �p�l���\��
            onShootPanel.SetActive(true);

            // Button�ݒ�
            {
                strongShootButton = onShootPanel.transform.Find("StrongShootButton").gameObject.GetComponent<Button>();
                normalShootButton = onShootPanel.transform.Find("NormalShootButton").gameObject.GetComponent<Button>();
            }

            // Button����
            {
                strongShootButton.enabled = true;
                normalShootButton.enabled = true;
                if (userCommandModel.hp < 20) { strongShootButton.enabled = false; }
            }
            
            // Button���s����
            {
                OnStrongShootButton.AddListener(() => {
                    userCommandModel.hp -= 20;
                    battle.CommandBattle(this.userObject, collisionObject, "StrongShoot");
                    Close();
                    OnStrongShootButton.RemoveAllListeners();
                });
                OnNormalShootButton.AddListener(() => {
                    battle.CommandBattle(this.userObject, collisionObject, "NormalShoot");
                    Close();
                    OnNormalShootButton.RemoveAllListeners();
                });
            }
        }
    }

    //Button�ݒ�̏�����
    public void ButtonReset()
    {
        passButton = null;
        passCutButton = null;
        dribbleButton = null;
        dribbleCutButton = null;
        shootButton = null;
        strongShootButton = null;
        normalShootButton = null;
    }

    //�S�Ẵp�l�������
    public void Close()
    {
        ButtonReset();
        uve.SetActive(false);
        uvg.SetActive(false);
        onPassPanel.SetActive(false);
        onShootPanel.SetActive(false);
    }

    //Button�̃N���b�N����
    public Button.ButtonClickedEvent OnPassButton
    {
        get
        {
            return passButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnPassCutButton
    {
        get
        {
            return passCutButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnDribbleButton
    {
        get
        {
            return dribbleButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnDribbleCutButton
    {
        get
        {
            return dribbleCutButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnShootButton
    {
        get
        {
            return shootButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnStrongShootButton
    {
        get
        {
            return strongShootButton.onClick;
        }
    }
    public Button.ButtonClickedEvent OnNormalShootButton
    {
        get
        {
            return normalShootButton.onClick;
        }
    }
}
